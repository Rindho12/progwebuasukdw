<?php
defined('PATH') or exit('No direct script.');
?>
<div class="columns multiline marged centered" id="dashboard">
  <div class="column col-3 columns centered middled multiline">
    <p class="title column text-center">Jumlah Pesan</p>
    <p class="sub-title column text-center"><?= $jmlhPesan ?></p>
  </div>
  <div class="column col-3 columns centered middled multiline">
    <p class="title column text-center">Jumlah Galeri</p>
    <p class="sub-title column text-center"><?= $jmlhGaleri ?></p>
  </div>
</div>